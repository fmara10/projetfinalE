document.querySelector('.btn-primary').addEventListener('click', function() {
    alert('Produit ajouté au panier!');
});